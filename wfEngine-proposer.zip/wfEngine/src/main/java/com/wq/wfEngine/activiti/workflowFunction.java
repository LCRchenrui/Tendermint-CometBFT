package com.wq.wfEngine.activiti;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


import org.activiti.bpmn.model.Activity;
import org.activiti.bpmn.model.BpmnModel;
import org.activiti.bpmn.model.Process;

import org.activiti.bpmn.model.ServiceTask;
import org.activiti.bpmn.model.UserTask;
import org.activiti.engine.HistoryService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.impl.db.redis.workflowContext;
import org.activiti.engine.impl.db.redis.tools.operation.operations.operation;
import org.activiti.engine.impl.db.redis.tools.operation.operations.operation.oType;
import org.activiti.engine.impl.db.workflowClass.cachedResponse;
import org.activiti.engine.impl.db.workflowClass.randomGenerator;
import org.activiti.engine.impl.db.workflowClass.workflowResponse;
import org.activiti.engine.repository.Deployment;
import org.activiti.image.impl.DefaultProcessDiagramGenerator;
import org.apache.commons.lang3.tuple.Pair;

import com.wq.wfEngine.cache.cachedData;
import com.wq.wfEngine.cache.cachedServiceTaskResult;
import com.wq.wfEngine.config.evilNodeConfig;
//import com.wq.wfEngine.taskService.locks.unReleaseUrls;
import com.wq.wfEngine.tool.jsonTransfer;


public class workflowFunction {
    public static ProcessEngine processEngine = ActivitiUtils.processEngine;
    public static RepositoryService repositoryService = ActivitiUtils.repositoryService;
    public static TaskService taskService = ActivitiUtils.taskService;
    public static RuntimeService runtimeService = ActivitiUtils.runtimeService;
    public static HistoryService historyService = ActivitiUtils.historyService;

    //Map<String,Map<String,flowNode>> deployment_flowMap=new HashMap<>();//BPMN model activitiID到flowNode的映射

    
    public static List<Deployment> getAllDeployments() {
        List<Deployment> deployments=repositoryService.createDeploymentQuery().list();
        return deployments;
    }

    //这是因为mybatis数据库连接池隔一段时间会失效，并且连接池不会去做检验，当时改了配置文件仍然没用，就先用了这个方法
    public static void loop() {
        repositoryService.createProcessDefinitionQuery().list();
        runtimeService.createProcessInstanceQuery().list();
    }


    //获取bpmn的矢量图
    public static String getSvgContent(String deploymentName) throws IOException {
        BpmnModel model=cachedData.getBpmnModelByName(deploymentName);
        if (model!=null&&model.getLocationMap().size()>0) {
            DefaultProcessDiagramGenerator ge = new DefaultProcessDiagramGenerator();
            InputStream in = ge.generateDiagram(model,"宋体", "宋体", "宋体");
            byte[] bytes=new byte[in.available()];
            in.read(bytes);
            in.close();
            return new String(bytes);
        } else {
            throw new RuntimeException("bpmnModel 为空");
        }
    }

    public static void deleteDeploymentByName(String deploymentName) {
        List<Deployment> deploymentList = repositoryService.createDeploymentQuery().deploymentName(deploymentName).list();
        if (deploymentList.size()==0) {
            throw new RuntimeException("there is no deployment named "+deploymentName);
        }
        for (Deployment d : deploymentList) {
            repositoryService.deleteDeployment(d.getId(), true);// 默认是false true就是级联删除
        }

        cachedData.cleanDeploymentByName(deploymentName);
    }

    //过滤掉deployments中包含用户任务的，当时是为了智慧城市
    public static List<String> filterUserTask(List<Deployment> deployments) {
        List<String> deploymentWithNoUserTask=new ArrayList<>();
        for (Deployment deployment:deployments) {
            if (!cachedData.haveUserTask(deployment.getName())) {
                deploymentWithNoUserTask.add(deployment.getName());
            }
        }
        return deploymentWithNoUserTask;
    }

    //过滤非dbapi
    public static List<String> filterNoDBAPI(List<Deployment> deployments) {
        List<String> deploymentDBAPI=new ArrayList<>();
        for (Deployment deployment:deployments) {
            if (cachedData.isDBAPI(deployment.getName())) {
                deploymentDBAPI.add(deployment.getName());
            }
        }
        return deploymentDBAPI;
    }


    //智慧城市，拿到serviceTaskInfo
    public static Map<String,Object> getServiceTaskInfo(List<String> deploymentNames) {
        Map<String,Object> serviceTaskInfos=new HashMap<>();
        for (String deploymentName:deploymentNames) {
            serviceTaskInfos.put(deploymentName,cachedData.getServiceTaskInfo(deploymentName));
        }
        return serviceTaskInfos;
    }


    public static String getBytesByDeployment(Deployment deployment) throws IOException {
        InputStream in=repositoryService.getResourceAsStream(deployment.getId(), deployment.getName());
        byte[] bytes=new byte[in.available()];
        in.read(bytes);
        in.close();
        return new String(bytes);
    }

    public static String getBytesByDeploymentName(String deploymentName) throws IOException {
        Deployment deployment=repositoryService.createDeploymentQuery().deploymentName(deploymentName).singleResult();
        if (deployment==null) throw new RuntimeException("there is no deployment with name is "+deploymentName);
        InputStream in=repositoryService.getResourceAsStream(deployment.getId(), deployment.getName());
        byte[] bytes=new byte[in.available()];
        in.read(bytes);
        in.close();
        return new String(bytes);
    }

    // 按部署名重新部署一份bpmn，并把部署结果先放进缓存，等到后续flush正式生效
    public static String deploy(String deploymentName,String fileContent, boolean consensusPayload) {
        // 查找同名旧部署
        List<Deployment> deploymentList = repositoryService.createDeploymentQuery().deploymentName(deploymentName).list();
        // 删除旧部署
        // 要把引擎里的部署切换到新版本
        for (Deployment d : deploymentList) {
            repositoryService.deleteDeployment(d.getId(), true);// 默认是false true就是级联删除
        }
        // 清理本地缓存中的该部署，避免缓存里残留旧版本deployment的映射信息
        cachedData.cleanDeploymentByName(deploymentName);
        // 创建新部署，把传入的BPMN文本fileContent以deploymentName部署到Activiti
        Deployment deployment = repositoryService.createDeployment()// 创建Deployment对象
        .addString(deploymentName, fileContent)
        .name(deploymentName)
        .deploy();//对于deployment,Name就是他的Oid

        // 获取新部署的workflowResponse，并存入缓存，等待flush时更新，对应实例的状态
        cachedResponse response= runtimeService.getWorkflowResponse(deploymentName);

        // 存至缓存，等待flush时更新，对应实例的状态
        // 把这次操作结果放进缓存，等后面flush再统一确认状态
        cachedData.storeWorkflowResponse(response, deploymentName);

        if (consensusPayload) {
            return new workflowResponse(response).getConsensusJson();
        }
        return response.getEncodeString();
        //return response.getResponseString();
    }


    /**
     * 
     * @param deploymentName 要实例化的bpmn图对应的Deployment的名字
     * @param Oid 实例的唯一oid
     * @param businessData 这个是传入的业务数据
     * @param staticAllocationTable 这个是静态分配表
     * @param serviceTaskResultJson 如果不是这个接受请求的节点为null,否则为接受请求的节点先执行的结果
     * @return 返回的是模拟执行后的结果序列化后用base64加密后的字符串
     */
    public static String instance(String deploymentName,String Oid,String businessData,String staticAllocationTable,String serviceTaskResultJson, boolean consensusPayload) {
        // 恶意节点短路（测试/容错逻辑，为了模拟拜占庭/异常节点行为）
        // 为了验证系统在有坏节点的情况下还能否正常工作，需要故意制造异常节点行为
        if (evilNodeConfig.isEvil()) {
            return randomGenerator.getWorkflowResponseString();
        }
        Map<String,Object> table=null;
        if (staticAllocationTable!=null) {
            table=jsonTransfer.jsonToMap(staticAllocationTable);
            if (table==null) throw new RuntimeException("jsonTransfer error,jsonStr:"+staticAllocationTable);
        }
        workflowContext.getUserTaskBindHandler().staticAllocate(Oid,table);
        // 组装流程变量，传入Oid唯一标识
        Map<String,Object> variables=new HashMap<String,Object>() {
            {
                put("Oid",Oid);
            };
        };
        if (businessData.length()>=2) {
            variables.put("businessData",businessData);
        }
        // 如果是预先执行的设置serviceTaskResultJson
        if (serviceTaskResultJson!=null) {
            variables.put("serviceTaskResultJson",serviceTaskResultJson);
        }
        //拿到需要实例化的第一个流程Id
        String mainProcessId=cachedData.getMainProcessId(deploymentName);
        //实例化
        // 真正启动流程实例，这一步就是Activiti真正起实例
        runtimeService.startProcessInstanceById(mainProcessId,variables);
        //拿到实例化的workflowResponse
        cachedResponse response=runtimeService.getWorkflowResponse(Oid);
        

        //存至缓存，等待flush时更新，对应实例的状态
        cachedData.storeWorkflowResponse(response, Oid);
        //如果是预先执行的设置serviceTaskResultJson
        response.setServiceTaskResultJson(jsonTransfer.serviceTaskResToJsonString(cachedServiceTaskResult.removeServiceTaskRes(Oid)));
        //返回给请求方的数据
        if (consensusPayload) {
            return new workflowResponse(response).getConsensusJson();
        }
        return response.getEncodeString(); 
        // try {
        //     //拿到需要实例化的第一个流程Id
        //     String mainProcessId=cachedData.getMainProcessId(deploymentName);
        //     //实例化
        //     runtimeService.startProcessInstanceById(mainProcessId,variables);
        //     //拿到实例化的workflowResponse
        //     cachedResponse response=runtimeService.getWorkflowResponse(Oid);
            

        //     //存至缓存，等待flush时更新，对应实例的状态
        //     cachedData.storeWorkflowResponse(response, Oid);
        //     //如果是预先执行的设置serviceTaskResultJson
        //     response.setServiceTaskResultJson(jsonTransfer.serviceTaskResToJsonString(cachedServiceTaskResult.removeServiceTaskRes(Oid)));
        //     response.setServiceUrls(unReleaseUrls.getUrls());
        //     //返回给请求方的数据
        //     return response.getEncodeString(); 
        // } catch (Exception e) {
        //     if (!e.getMessage().contains("加锁失败")) unReleaseUrls.rollBack(Oid);
        //     throw e;
        // } finally {
        //     unReleaseUrls.reset();
        // }
    }


    // 根据Oid+taskName找到当前任务，带上变量去taskService.complete()完成任务，然后把结果缓存并返回

    public static String complete(String Oid,String taskName,String processData,String businessData,String user,String serviceTaskResultJson, boolean consensusPayload) {
        System.out.println("========== [workflowFunction] complete 开始执行 ==========");
        System.out.println("参数 - Oid: " + Oid);
        System.out.println("参数 - taskName: " + taskName);
        System.out.println("参数 - user: " + user);
        
        // 恶意节点短路
        if (evilNodeConfig.isEvil()) {
            return randomGenerator.getWorkflowResponseString();
        }
        
        System.out.println("从缓存中查找 taskId - Oid: " + Oid + ", taskName: " + taskName);
        // 查找当前任务实例里的任务ID
        String taskId=cachedData.getTaskId(Oid, taskName);
        System.out.println("查找结果 - taskId: " + (taskId != null ? taskId : "null"));
        
        if (taskId==null) {
            System.err.println("错误：找不到对应的任务！");
            System.err.println("Oid: " + Oid);
            System.err.println("taskName: " + taskName);
            System.err.println("可能的原因：");
            System.err.println("  1. 该 OID 对应的实例尚未初始化");
            System.err.println("  2. 该任务已经被完成");
            System.err.println("  3. OID 不正确");
            System.err.println("  4. 任务名称不正确");
            throw new RuntimeException("no task named "+taskName+" with oid "+Oid);
        }
        System.out.println("成功找到 taskId: " + taskId);
        // 组装流程变量，传入Oid唯一标识
        Map<String,Object> variables=jsonTransfer.jsonToMap(processData);
        //传入的变量中放入Oid唯一标识
        variables.put("Oid",Oid);
        variables.put("user",user);
        //如果有businessData则加入variables,因为business传入的是json数据的字符串格式
        //todo:businessData持久化
        if (businessData.length()>=2) {
            variables.put("businessData",businessData);
        }
        if (serviceTaskResultJson!=null) {
            variables.put("serviceTaskResultJson",serviceTaskResultJson);
        }
        //先完成complete
        // 从当前user task走到下一个节点
        taskService.complete(taskId, variables,false);
        // 获取当前实例的workflowResponse，包括下一任务、业务数据等
        cachedResponse response=runtimeService.getWorkflowResponse(Oid);

        //存至缓存，等待flush时更新，对应实例的状态
        cachedData.storeWorkflowResponse(response, Oid);
        //如果是预先执行的设置serviceTaskResultJson
        response.setServiceTaskResultJson(jsonTransfer.serviceTaskResToJsonString(cachedServiceTaskResult.removeServiceTaskRes(Oid)));

        //response.setServiceUrls(unReleaseUrls.getUrls());
        if (consensusPayload) {
            return new workflowResponse(response).getConsensusJson();
        }
        return response.getEncodeString();
        // try {
        //     //先完成complete
        //     taskService.complete(taskId, variables,false);

        //     cachedResponse response=runtimeService.getWorkflowResponse(Oid);

        //     //存至缓存，等待flush时更新，对应实例的状态
        //     cachedData.storeWorkflowResponse(response, Oid);
        //     //如果是预先执行的设置serviceTaskResultJson
        //     response.setServiceTaskResultJson(jsonTransfer.serviceTaskResToJsonString(cachedServiceTaskResult.removeServiceTaskRes(Oid)));

        //     response.setServiceUrls(unReleaseUrls.getUrls());
        //     return response.getEncodeString();
        // } catch (Exception e) {
        //     if (!e.getMessage().contains("加锁失败")) unReleaseUrls.rollBack(Oid);
        //     throw e;
        // } finally {
        //     unReleaseUrls.reset();
        // }
    }

    /**
     * @apiNote 根据读写集来完成状态更新，这里的读写集用的是json形式，protoBuf不够灵活，如果后期需要可以进行更改
     * @param value 读写集的json字符串,map结构{opType="操作类型",剩下的数据根据opType不一致}，底层有判断逻辑
     */
    public static boolean commonFlush(operation o) {
        return runtimeService.flush(o);
    }

    /**
     * 
     * @param o 模拟执行需要的参数封装的类，deploy,instance,complete还未集成进来
     * @return 返回给用户的数据，一般为读写集
     */
    public static String commonSimulate(operation o) {
        return runtimeService.simulate(o);
    }


    /**
     * @apiNote 这个没有做需要绑定的task是否已经执行完成，可以通过BpmnModel的序列流和信息流的广度遍历来做，但是或许可以有更好的方法
     * @param oid
     * @param taskName
     * @return pair<bool,oType> 有效则返回<true,oType>,无效返回<false,null>
     */
    public static Pair<Boolean,oType> isUserOrServiceTask(String oid,String taskName) {
        BpmnModel model=cachedData.getBpmnModelByName(oid.split("@")[0]);
        Iterator<Process> processes= model.getProcesses().iterator();
        //这个oid的流程已经执行完了
        Map<String,String> nowTasks=cachedData.getNowTasks(oid);
        if (nowTasks==null) return Pair.of(false, null);
        while (processes.hasNext()) {
            Process process=processes.next();
            Iterator<Activity> activities= process.findFlowElementsOfType(Activity.class, true).iterator();
            while (activities.hasNext()) {
                Activity activity=activities.next();
                if (activity instanceof UserTask) {
                    UserTask userTask=(UserTask)activity;
                    if (userTask.getName().equals(taskName)) return Pair.of(true, oType.userTaskBind);
                } else if (activity instanceof ServiceTask) {
                    ServiceTask serviceTask=(ServiceTask)activity;
                    if (serviceTask.getName().equals(taskName)) return Pair.of(true, oType.serviceTaskBind);
                }
            }
        }
        //没有找到对应的task
        return Pair.of(false, null);
    }


    // 引擎里把缓存结果正式提交并同步状态的关键函数
    /**
     * @apiNote 这个flush主要用于工作流deploy,instance,complete，因为现阶段的读写集太大，只能以缓存的方式实现flush
     * @param Oids
     */
    public static void flush(String[] Oids) {
        try {
            // 把这些Oid对应的缓存读写集/预执行结果做统一flush（提交/落地），等于把之前deploy/instance/complete暂存的结果真正推进
            runtimeService.flushCache(Oids);
            for (String Oid:Oids) {
                // 把当前任务映射、下一任务映射、已结束实例清理等缓存状态同步到最新
                cachedData.updateCurrentTaskStatus(Oid);
            } 
        } catch (Exception e) {
            for (StackTraceElement element:e.getStackTrace()) {
                System.out.println(element.toString());
            }
            System.out.println(e.getMessage());
            System.out.println(e.getCause().getMessage());
            throw e;
        }
        //runtimeService.flushCache(Oids);
        // for (String Oid:Oids) {
        //     cachedData.updateCurrentTaskStatus(Oid);
        // }
    }
    /**
     * 服务任务还没有适配，还需要进一步扩展
     */
}
