package com.wq.wfEngine.tool;

import java.sql.*;
import org.springframework.stereotype.Repository;


@Repository
public class TaskInfoRepository {

    private final String jdbcUrl = "jdbc:mysql://127.0.0.1:3306/workflow_info?useUnicode=true&characterEncoding=utf-8&serverTimezone=GMT";

    private final String user = "root";
    private final String password = "123456";

    public void insertTaskInfo(String oid, String task, String hash) {
        String sql = "INSERT INTO task_info (oid, task, hash) VALUES (?, ?, ?) "
                   + "ON DUPLICATE KEY UPDATE hash = VALUES(hash)";
        try (Connection conn = DriverManager.getConnection(jdbcUrl, user, password);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, oid);
            pstmt.setString(2, task);
            pstmt.setString(3, hash);
            pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("insert failed"+e.getMessage()+e.toString()+"new version", e);
        }
    }

    public String getHashByOidAndTask(String oid, String task) {
        String sql = "SELECT hash FROM task_info WHERE oid = ? AND task = ?";
        try (Connection conn = DriverManager.getConnection(jdbcUrl, user, password);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, oid);
            pstmt.setString(2, task);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getString("hash");
            } else {
                return null;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("查询数据失败"+e.toString(), e);
        }
    }
}