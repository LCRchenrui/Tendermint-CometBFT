package springcloud.springcloudgateway.workflow.tools;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.stereotype.Component;

/**
 * 对称加密客户端
 * 用于对JSON业务数据中的隐私字段进行AES加密/解密
 * 加密后字段保持字符串格式，便于JSON序列化
 */
@Component
public class SymmetricCryptoClient {
    
    private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES/ECB/PKCS5Padding";
    
    // 使用固定的密钥（生产环境应该从配置文件或密钥管理系统获取），32字节
    private SecretKey secretKey;
    
    public SymmetricCryptoClient() {
        try {
            // 初始化密钥（实际项目中应该从安全存储读取）
            initSecretKey();
        } catch (Exception e) {
            throw new RuntimeException("初始化对称加密密钥失败", e);
        }
    }
    
    /**
     * 初始化AES密钥
     * 生产环境应该从密钥管理系统或配置中心获取
     */
    private void initSecretKey() throws Exception {
        // 使用固定密钥（示例，实际应该从安全存储读取）
        String keyString = "WorkflowSymmetricKey123456789012345678"; // 32字节密钥
        secretKey = new SecretKeySpec(keyString.getBytes(StandardCharsets.UTF_8), ALGORITHM);
    }
    
    /**
     * 提取隐私字段的值，从JSON中提取隐私字段的值，返回按顺序的值列表
     * @param bd 业务数据JSON字符串
     * @param privateList 隐私字段列表（如：["energy_kwh","distanceKM",...]）
     * @return 隐私字段值的列表（按privateList顺序）
     */
    public List<String> extractPrivateFields(String bd, List<String> privateList) {
        List<String> values = new ArrayList<>();
        
        try {
            // 将JSON字符串转换为Map
            Map<String, Object> dataMap = jsonTransfer.jsonToMap(bd);
            
            // 按照privateList顺序提取字段值
            for (String fieldName : privateList) {
                if (dataMap.containsKey(fieldName)) {
                    Object value = dataMap.get(fieldName);
                    // 转换为字符串
                    String valueStr = (value != null) ? value.toString() : "";
                    values.add(valueStr);
                } else {
                    // 如果字段不存在，添加空字符串
                    values.add("");
                }
            }
            
        } catch (Exception e) {
            throw new RuntimeException("提取隐私字段失败: " + e.getMessage(), e);
        }
        
        return values;
    }
    
    /**
     * 加密业务数据中的隐私字段，即加密JSON中指定字段，其他字段保持不变
     * @param bd 业务数据JSON字符串
     * @param privateList 隐私字段列表（ciphermeta）
     * @return 加密后的业务数据JSON字符串
     */
    public String encrypt(String bd, List<String> privateList) {
        if (privateList == null || privateList.isEmpty()) {
            return bd;
        }
        
        try {
            // 将JSON字符串转换为Map
            Map<String, Object> dataMap = jsonTransfer.jsonToMap(bd);
            
            // 对每个隐私字段进行加密
            for (String fieldName : privateList) {
                if (dataMap.containsKey(fieldName)) {
                    Object value = dataMap.get(fieldName);
                    if (value != null) {
                        String plaintext = value.toString();
                        // 加密字段值
                        String ciphertext = encryptString(plaintext);
                        // 替换原值为密文
                        dataMap.put(fieldName, ciphertext);
                    }
                }
            }
            
            // 保留ciphermeta字段，便于后续解密
            dataMap.put("ciphermeta", privateList);
            
            // 转换回JSON字符串
            return jsonTransfer.mapToJsonString(dataMap);
            
        } catch (Exception e) {
            throw new RuntimeException("加密业务数据失败: " + e.getMessage(), e);
        }
    }
    
    /**
     * 解密业务数据中的隐私字段，即解密JSON中指定字段的密文，恢复为明文，密文字段恢复为原始明文，其他字段不变
     * @param bd 包含密文的业务数据JSON字符串
     * @param privateList 隐私字段列表（从ciphermeta字段获取）
     * @return 解密后的业务数据JSON字符串
     */
    public String decrypt(String bd, List<String> privateList) {
        if (privateList == null || privateList.isEmpty()) {
            return bd;
        }
        
        try {
            // 将JSON字符串转换为Map
            Map<String, Object> dataMap = jsonTransfer.jsonToMap(bd);
            
            // 对每个隐私字段进行解密
            for (String fieldName : privateList) {
                if (dataMap.containsKey(fieldName)) {
                    Object value = dataMap.get(fieldName);
                    if (value != null) {
                        String ciphertext = value.toString();
                        try {
                            // 尝试解密
                            String plaintext = decryptString(ciphertext);
                            // 替换密文为明文
                            dataMap.put(fieldName, plaintext);
                        } catch (Exception e) {
                            // 如果解密失败，可能是字段已经是明文，保留原值
                            System.err.println("解密字段 " + fieldName + " 失败，保留原值: " + e.getMessage());
                        }
                    }
                }
            }
            
            
            
            // 转换回JSON字符串
            return jsonTransfer.mapToJsonString(dataMap);
            
        } catch (Exception e) {
            throw new RuntimeException("解密业务数据失败: " + e.getMessage(), e);
        }
    }
    
    /**
     * 加密单个字符串，对单个字符串进行AES加密，返回Base64密文
     * @param plaintext 明文
     * @return Base64编码的密文
     */
    private String encryptString(String plaintext) throws Exception {
        if (plaintext == null || plaintext.isEmpty()) {
            return plaintext;
        }
        
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
        byte[] encryptedBytes = cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));
        
        // 返回Base64编码的密文字符串
        return Base64.getEncoder().encodeToString(encryptedBytes);
    }
    
    /**
     * 将Base64密文解密为明文字符串
     * @param ciphertext Base64编码的密文
     * @return 明文
     */
    private String decryptString(String ciphertext) throws Exception {
        if (ciphertext == null || ciphertext.isEmpty()) {
            return ciphertext;
        }
        
        try {
            // 尝试Base64解码
            byte[] encryptedBytes = Base64.getDecoder().decode(ciphertext);
            
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
            
            return new String(decryptedBytes, StandardCharsets.UTF_8);
        } catch (IllegalArgumentException e) {
            // 如果不是Base64格式，可能是明文，直接返回
            return ciphertext;
        }
    }
    
    /**
     * 从业务数据中提取ciphermeta字段
     * @param bd 业务数据JSON字符串
     * @return ciphermeta字段列表，如果不存在返回null
     */
    public List<String> extractCipherMeta(String bd) {
        try {
            Map<String, Object> dataMap = jsonTransfer.jsonToMap(bd);
            Object ciphermetaObj = dataMap.get("ciphermeta");
            
            if (ciphermetaObj instanceof List<?>) {
                List<String> ciphermeta = new ArrayList<>();
                for (Object item : (List<?>) ciphermetaObj) {
                    if (item instanceof String) {
                        ciphermeta.add((String) item);
                    }
                }
                return ciphermeta;
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }
    

}

