package main

import (
	"context"
	"encoding/json"
	"log"
	"net/http"
	"os"
	"time"

	abciserver "github.com/tendermint/tendermint/abci/server"
	tmlog "github.com/tendermint/tendermint/libs/log"

	"wfconsensusbridge/internal/abciapp"
	"wfconsensusbridge/internal/app"
	"wfconsensusbridge/internal/executor"
)

func main() {
	// 读取环境变量
	abciAddr := getenv("WF_ABCI_ADDR", "tcp://127.0.0.1:26658") // ABCI socket地址
	httpAddr := getenv("WF_HTTP_ADDR", ":8787") // HTTP监听地址
	wfBase := getenv("WF_ENGINE_BASE", "http://127.0.0.1:8888") // 工作流引擎基础URL，wfEngine地址，确定一下

	// 组装核心对象
	core := app.New() // 创建状态机核心（交易验证、入队、状态管理）
	exec := executor.New(core, wfBase) // 创建执行器（从队列取交易并调用wfEngine）

	// 启后台worker，每2秒从队列取交易并执行，异步消费一条pending交易并执行（deploy/instance/complete）
	// 也就是每隔2s做一次：去队列里看看有没有pending（待执行）交易，有的话就执行；有就拿一条出来执行（调用wfEngine）；没有就什么都不做，等下一轮
	// 交易先经过Tendermint共识后，abciapp.DeliverTx()会把它记到app的状态里，并标记pending
	go func() { // 定时执行器，每2秒从队列取交易并执行
		tk := time.NewTicker(2 * time.Second)
		defer tk.Stop()
		for range tk.C {
			_, _ = exec.RunOnce(context.Background())  //这个函数具体是怎么执行的
		}
	}()

	// 启动ABCI服务，监听ABCI socket地址，接收Tendermint共识交易，并调用abciapp.DeliverTx()处理
	s := abciserver.NewSocketServer(abciAddr, abciapp.New(core))
	s.SetLogger(tmlog.NewTMLogger(tmlog.NewSyncWriter(os.Stdout)))
	if err := s.Start(); err != nil {
		log.Fatal(err)
	}
	defer s.Stop()

	// 启HTTP服务，监听HTTP地址，提供状态查询接口
	mux := http.NewServeMux()
	mux.HandleFunc("/state", func(w http.ResponseWriter, _ *http.Request) {
		_ = json.NewEncoder(w).Encode(core.State())
	})
	go func() {
		if err := http.ListenAndServe(httpAddr, mux); err != nil {
			log.Fatal(err)
		}
	}()

	log.Printf("ABCI on %s, HTTP on %s, wfEngine=%s", abciAddr, httpAddr, wfBase)
	select {}
}

func getenv(k string, d string) string {
	v := os.Getenv(k)
	if v == "" {
		return d
	}
	return v
}
